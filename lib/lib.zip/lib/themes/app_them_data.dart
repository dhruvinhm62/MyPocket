class AppThemData {
  static const String regular = 'Figtree-Regular';
  static const String medium = 'Figtree-Medium';
  static const String bold = 'Figtree-Bold';
  static const String semiBold = 'Figtree-SemiBold';
}
