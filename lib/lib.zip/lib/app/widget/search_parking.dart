import 'package:flutter/material.dart';

class SearchParking extends StatelessWidget {
  const SearchParking({super.key});

  @override
  Widget build(BuildContext context) {

    return Container();
  }
}
