import 'package:get/get.dart';

class CompletedScreenController extends GetxController {

}
