import 'package:get/get.dart';

class WelcomeScreenController extends GetxController {
  //TODO: Implement WelcomeScreenController


}
