import 'package:get/get.dart';

class CancelScreenController extends GetxController {

}
