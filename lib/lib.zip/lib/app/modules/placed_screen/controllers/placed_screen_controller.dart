import 'package:get/get.dart';

class PlacedScreenController extends GetxController {

}
